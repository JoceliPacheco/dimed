
export interface Lista{
    id:number;
    codigo:string;
    nome:string;
}
