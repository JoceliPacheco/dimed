import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-erro404',
  templateUrl: './erro404.component.html' 
})
export class Erro404Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
